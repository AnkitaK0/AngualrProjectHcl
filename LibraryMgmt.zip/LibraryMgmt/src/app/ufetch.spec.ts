import { Ufetch } from './ufetch';

describe('Ufetch', () => {
  it('should create an instance', () => {
    expect(new Ufetch()).toBeTruthy();
  });
});
