import { Userfetch } from './userfetch';

describe('Userfetch', () => {
  it('should create an instance', () => {
    expect(new Userfetch()).toBeTruthy();
  });
});
