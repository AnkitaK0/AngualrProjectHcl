export class Userfetch {
    static module(arg0: string, arg1: undefined[]) {
      throw new Error('Method not implemented.');
    }
    id: number = 0;
    username: String = "";
    password: String = "";
    loginAs: String = "";
}
